package Test;
import org.junit.Test;
import Default.ComparablePoint;
import Default.Segment;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import static org.junit.Assert.assertEquals;

public class SegmentTest {
	
	@Test
	public void horizontalTest(){
		ComparablePoint p = new ComparablePoint(new Double(5,10));
		ComparablePoint p2 = new ComparablePoint(new Double(10,10));
		Segment s = new Segment(null, 0, p, p2);
		assertTrue(s.isHorizontal());
	}
	
	@Test
	public void verticalTest(){
		ComparablePoint p = new ComparablePoint(new Double(50,10));
		ComparablePoint p2 = new ComparablePoint(new Double(50,20));
		Segment s = new Segment(null, 0, p, p2);
		assertTrue(s.isVertical());
	}
	
	@Test
	public void notVerticalnotHorizontalTest(){
		ComparablePoint p = new ComparablePoint(new Double(50,10));
		ComparablePoint p2 = new ComparablePoint(new Double(56,20));
		Segment s = new Segment(null, 0, p, p2);
		assertTrue(!(s.isVertical() && s.isHorizontal()));
	}
	
	@Test
	public void intersectNotHoriNotVerti(){
		ComparablePoint p = new ComparablePoint(new Double(20,40));
		ComparablePoint p2 = new ComparablePoint(new Double(40,20));
		
		ComparablePoint p3 = new ComparablePoint(new Double(10,10));
		ComparablePoint p4 = new ComparablePoint(new Double(40,40));
		Segment s = new Segment(null, 0, p, p2);
		Segment s2 = new Segment(null, 0, p3, p4);
		
		Point2D.Double normalIntersection = new Point2D.Double(30,30);
		
		Point2D.Double calculatedIntersection = s.findIntersectionWithSegment(s2);
		
		assertTrue(normalIntersection.equals(calculatedIntersection));
	}
	
	@Test
	public void intersectHori(){
		ComparablePoint p = new ComparablePoint(new Double(0,30));
		ComparablePoint p2 = new ComparablePoint(new Double(100,30));
		
		ComparablePoint p3 = new ComparablePoint(new Double(10,10));
		ComparablePoint p4 = new ComparablePoint(new Double(40,40));
		Segment s = new Segment(null, 0, p, p2);
		Segment s2 = new Segment(null, 0, p3, p4);
		
		Point2D.Double normalIntersection = new Point2D.Double(30,30);
		
		Point2D.Double calculatedIntersection = s.findIntersectionWithSegment(s2);
		
		assertTrue(normalIntersection.equals(calculatedIntersection));
	}
	
	@Test
	public void intersectVerti(){
		ComparablePoint p = new ComparablePoint(new Double(30,0));
		ComparablePoint p2 = new ComparablePoint(new Double(30,100));
		
		ComparablePoint p3 = new ComparablePoint(new Double(10,10));
		ComparablePoint p4 = new ComparablePoint(new Double(40,40));
		Segment s = new Segment(null, 0, p, p2);
		Segment s2 = new Segment(null, 0, p3, p4);
		
		Point2D.Double normalIntersection = new Point2D.Double(30,30);
		
		Point2D.Double calculatedIntersection = s.findIntersectionWithSegment(s2);
		
		assertTrue(normalIntersection.equals(calculatedIntersection));
	}
	
	@Test
	public void notIntersectVerti(){
		ComparablePoint p = new ComparablePoint(new Double(30,50));
		ComparablePoint p2 = new ComparablePoint(new Double(30,100));
		
		ComparablePoint p3 = new ComparablePoint(new Double(10,10));
		ComparablePoint p4 = new ComparablePoint(new Double(40,40));
		Segment s = new Segment(null, 0, p, p2);
		Segment s2 = new Segment(null, 0, p3, p4);
		
		Point2D.Double normalIntersection = new Point2D.Double(30,30);
		
		Point2D.Double calculatedIntersection = s.findIntersectionWithSegment(s2);
		
		assertFalse(normalIntersection.equals(calculatedIntersection));
	}
	
	@Test
	public void notIntersectHori(){
		ComparablePoint p = new ComparablePoint(new Double(50,30));
		ComparablePoint p2 = new ComparablePoint(new Double(100,30));
		
		ComparablePoint p3 = new ComparablePoint(new Double(10,10));
		ComparablePoint p4 = new ComparablePoint(new Double(40,40));
		Segment s = new Segment(null, 0, p, p2);
		Segment s2 = new Segment(null, 0, p3, p4);
		
		Point2D.Double normalIntersection = new Point2D.Double(30,30);
		
		Point2D.Double calculatedIntersection = s.findIntersectionWithSegment(s2);
		
		assertFalse(normalIntersection.equals(calculatedIntersection));
	}
	
	@Test
	public void notIntersectNormal(){
		ComparablePoint p = new ComparablePoint(new Double(100,90));
		ComparablePoint p2 = new ComparablePoint(new Double(87,52));
		
		ComparablePoint p3 = new ComparablePoint(new Double(10,10));
		ComparablePoint p4 = new ComparablePoint(new Double(40,40));
		Segment s = new Segment(null, 0, p, p2);
		Segment s2 = new Segment(null, 0, p3, p4);
		
		Point2D.Double normalIntersection = new Point2D.Double(30,30);
		
		Point2D.Double calculatedIntersection = s.findIntersectionWithSegment(s2);
		
		assertFalse(normalIntersection.equals(calculatedIntersection));
	}
}
