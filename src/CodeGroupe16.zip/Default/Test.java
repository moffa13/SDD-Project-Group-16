package Default;
import Graphics.MainWindow;

public class Test {

	public static void main(String[] args) {
		
		new MainWindow();
		
	}

}
