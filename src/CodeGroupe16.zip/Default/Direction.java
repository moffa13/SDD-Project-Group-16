package Default;

public enum Direction {
	LEFT,
	RIGHT
}
